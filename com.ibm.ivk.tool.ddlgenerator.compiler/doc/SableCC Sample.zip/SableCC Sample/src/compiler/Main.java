package compiler;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PushbackReader;

import sablecc.lexer.Lexer;
import sablecc.node.EOF;
import sablecc.node.Token;
import sablecc.parser.Parser;

public class Main {

	/**
	 * Die Methode f�hrt einen kompletten Kompeliervorgang durch.
	 */
	public static void main(String[] args) throws Exception {
		// Eingabe-Datei einlesen und den Lexer diese verarbeiten lassen
		Lexer lexer = new Lexer(new PushbackReader(new BufferedReader(new FileReader("input/Eingabe.txt")), 1024));
		// den Parser die Ausgabe vom Lexer verarbeiten lassen
		Parser parser = new Parser(lexer);
		// den vom Parser erzeugten Syntaxbaum mit hilfe von einem Visitor traversieren
		Visitor visitor = new Visitor();
		parser.parse().apply(visitor);
				
		// Ausgabe-Datei erstellen
		try {
			FileWriter writer = new FileWriter("output/Ausgabe.txt", false);
			writer.write(visitor.getResult().toString());
			writer.flush();
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("FERTIG!!");
	}

	/**
	 * Die Methode f�hrt nur den Scanner aus und gibt in der Konsole aus, in welche lexikalischen Einheiten (Tokens) die Eingabe zerteilt wird.
	 */
	public static void mainT(String[] args) throws Exception {
		Lexer lexer = new Lexer(new PushbackReader(new BufferedReader(new FileReader("input/Eingabe.txt")), 1024));
		
		// solange der Lexer nicht das Ende der Eingabe erreicht hat
		while (!(lexer.peek() instanceof EOF)) {
			Token token = lexer.next();
			String[] parts = token.getClass().toString().split("\\.");
			
			// die lexikalische Einheit und den Typ des Tokens ausgeben
			System.out.println(token.getText() + " --> " + parts[parts.length - 1]);
		}
		System.out.println("FERTIG!!");
	}
}