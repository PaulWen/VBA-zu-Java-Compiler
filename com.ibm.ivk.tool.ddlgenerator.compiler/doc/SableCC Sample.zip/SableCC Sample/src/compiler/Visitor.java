package compiler;

import sablecc.analysis.DepthFirstAdapter;
import sablecc.node.AComment;
import sablecc.node.ACommentStatment;
import sablecc.node.AConstModifier;
import sablecc.node.AEndOfLineStatment;
import sablecc.node.AGlobalModifier;
import sablecc.node.AId;
import sablecc.node.AIntegerDataType;
import sablecc.node.APrivateModifier;
import sablecc.node.AStringDataType;
import sablecc.node.AVarDec;
import sablecc.node.AVarDecStatment;
import sablecc.node.PModifier;

public class Visitor extends DepthFirstAdapter {

	
/////////////////////////////////////////////////Datenfelder/////////////////////////////////////////////////
	
	/** Das Datenfeld speichert die Ausgabe, die vom Visitor erzeugt wird. */
	private StringBuffer result;

/////////////////////////////////////////////////Konstruktor/////////////////////////////////////////////////

	/**
	 * Der Konstruktor der Klasse {@link DepthFirstAdapter}.
	 */
	public Visitor() {
		result = new StringBuffer();
	}

//////////////////////////////////////////////Getter und Setter//////////////////////////////////////////////

	/**
	 * Die Methode gibt die Ausgabe, die der Visitor erzeugt hat, aus.
	 * 
	 * @return die vom Visitor erzeugte Ausgabe
	 */
	public StringBuffer getResult() {
		return result;
	}
	
///////////////////////////////////////////////geerbte Methoden//////////////////////////////////////////////
	
	// Statment
	@Override
	public void caseACommentStatment(ACommentStatment node) {
		String result = "";
		
		Visitor visitor = new Visitor();
		node.getComment().apply(visitor);
		result += visitor.getResult();

		result += "\n";
		
		this.result.append(result);
	}
	@Override
	public void caseAVarDecStatment(AVarDecStatment node) {
		String result = "";
		
		Visitor visitor = new Visitor();
		node.getVarDec().apply(visitor);
		result += visitor.getResult();

		result += ";\n";
		
		this.result.append(result);
	}
	@Override
	public void caseAEndOfLineStatment(AEndOfLineStatment node) {
		String result = "";
		
		result += "\n";
		
		this.result.append(result);
	}
	
	
	// Modifier
	@Override
	public void caseAGlobalModifier(AGlobalModifier node) {
		String result = "public static";
		this.result.append(result);
	}
	
	@Override
	public void caseAPrivateModifier(APrivateModifier node) {
		String result = "private static";
		this.result.append(result);
	}
	
	@Override
	public void caseAConstModifier(AConstModifier node) {
		String result = "final";
		this.result.append(result);
	}
	
	// Datentypen
	@Override
	public void caseAIntegerDataType(AIntegerDataType node) {
		String result = "int";
		this.result.append(result);
	}
	
	@Override
	public void caseAStringDataType(AStringDataType node) {
		String result = "String";
		this.result.append(result);
	}
	
	// Kommentar
	@Override
	public void caseAComment(AComment node) {
		String result = "";
		
		result += "// ";
		result += node.getCommentToken().getText().substring(1, node.getCommentToken().getText().length());
		
		this.result.append(result);
	}
	
	// Id
	@Override
	public void caseAId(AId node) {
		String result = "";
		
		result += node.getIdToken().getText();
		// falls ID "default" hei�t diese Id zuerst umbennenen, da "default" in Java ein Schl�sselwort ist
		if (result.equals("default")) {
			result = "defaultValue";
		}
		
		this.result.append(result);
	}
	
	// Variablendeklaration
	@Override
	public void caseAVarDec(AVarDec node) {
		String result = "";
		
		for (PModifier modifier : node.getModifier()) {
			Visitor modifierVisitor = new Visitor();
			modifier.apply(modifierVisitor);
			result += modifierVisitor.getResult() + " ";
		}
		
		Visitor dataTypeVisitor = new Visitor();
		node.getDataType().apply(dataTypeVisitor);
		result += dataTypeVisitor.getResult() + " ";
		
		
		Visitor idVisitor = new Visitor();
		node.getId().apply(idVisitor);
		result += idVisitor.getResult().toString();
		
		this.result.append(result);
	}
}